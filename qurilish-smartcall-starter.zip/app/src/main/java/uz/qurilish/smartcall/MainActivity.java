package uz.qurilish.smartcall;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private JSONArray clients;
    private LinearLayout list;
    private TextView count, total;
    private int green = Color.rgb(23,107,85);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("smartcall", MODE_PRIVATE);
        try { clients = new JSONArray(prefs.getString("clients", "[]")); }
        catch(Exception e) { clients = new JSONArray(); }
        buildScreen();
        render();
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 8, 0, 8); return t;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title = text("Qurilish SmartCall", 26, green); title.setGravity(Gravity.CENTER);
        root.addView(title);
        root.addView(text("Qarzdorlikni eslatish boshqaruvi", 14, Color.DKGRAY));
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(0);
        count = text("Mijozlar: 0",16,green); total = text("Jami qarz: 0 so‘m",16,green);
        stats.addView(count,new LinearLayout.LayoutParams(0,-2,1)); stats.addView(total,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(stats);
        Button add = new Button(this); add.setText("＋ Qarzdor qo‘shish"); add.setOnClickListener(v -> addClient()); root.addView(add);
        Button info = new Button(this); info.setText("Avtomatik qo‘ng‘iroqlar sozlamasi"); info.setOnClickListener(v ->
            new AlertDialog.Builder(this).setTitle("Qo‘ng‘iroq xizmati")
            .setMessage("Avtomatik qo‘ng‘iroqlarni ulash uchun telefon/SIP provayderi va mijoz roziligi talab qilinadi. Bu boshlang‘ich versiyada qo‘ng‘iroqlar hali ulanmagan.")
            .setPositiveButton("Tushunarli",null).show()); root.addView(info);
        root.addView(text("Qarzdorlar ro‘yxati",20,Color.BLACK));
        list = new LinearLayout(this); list.setOrientation(1); root.addView(list);
        scroll.addView(root); setContentView(scroll);
    }
    private void addClient() {
        LinearLayout form = new LinearLayout(this); form.setPadding(8,8,8,8); form.setOrientation(1);
        EditText name = new EditText(this); name.setHint("Mijoz ismi"); form.addView(name);
        EditText phone = new EditText(this); phone.setHint("Telefon: +998..."); phone.setInputType(3); form.addView(phone);
        EditText debt = new EditText(this); debt.setHint("Qarz summasi (so‘m)"); debt.setInputType(2); form.addView(debt);
        EditText due = new EditText(this); due.setHint("To‘lov sanasi (masalan 25.11.2026)"); form.addView(due);
        new AlertDialog.Builder(this).setTitle("Yangi qarzdor").setView(form)
            .setNegativeButton("Bekor qilish",null)
            .setPositiveButton("Saqlash",(d,w)->{
                String n=name.getText().toString().trim(), p=phone.getText().toString().trim(), a=debt.getText().toString().trim();
                if(n.isEmpty() || p.isEmpty() || a.isEmpty()) { Toast.makeText(this,"Ism, telefon va qarz summasini kiriting",Toast.LENGTH_LONG).show(); return; }
                try {
                    JSONObject o=new JSONObject(); o.put("name",n); o.put("phone",p); o.put("debt",Long.parseLong(a)); o.put("due",due.getText().toString().trim());
                    clients.put(o); save(); render();
                } catch(Exception e) { Toast.makeText(this,"Ma’lumotni tekshiring",Toast.LENGTH_SHORT).show(); }
            }).show();
    }
    private void save(){ prefs.edit().putString("clients",clients.toString()).apply(); }
    private void render() {
        list.removeAllViews(); long sum=0;
        for(int i=0;i<clients.length();i++) try {
            JSONObject o=clients.getJSONObject(i); sum+=o.optLong("debt");
            TextView row=text(o.optString("name")+"\n"+o.optString("phone")+"\nQarz: "+o.optLong("debt")+" so‘m  |  Muddat: "+o.optString("due"),16,Color.DKGRAY);
            row.setBackgroundColor(Color.WHITE); row.setPadding(16,16,16,16);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,8,0,8); list.addView(row,lp);
        } catch(Exception ignored) {}
        count.setText("Mijozlar: "+clients.length()); total.setText("Jami qarz: "+sum+" so‘m");
        if(clients.length()==0) list.addView(text("Hozircha qarzdorlar yo‘q. “Qarzdor qo‘shish” tugmasini bosing.",15,Color.GRAY));
    }
}
